import pytest
import time
import os
from json_data import jsontestdata
from api import get_holidays


def test_mandatory_fields_in_get_api():
    input_data = jsontestdata('test_mandatory_fields.json')
    for input in input_data:
        get_holidays.request_for_holidays_list(input['key'], input['country'], input['year'])


def test_additional_fields_in_get_api():
    input_data = jsontestdata('test_additional_fields.json')
    for input in input_data:
        get_holidays.request_for_holidays_with_additional_fields(input['key'], input['country'], input['year'],input['month'],input['day'])


def test_negative_mandatory_in_get_api():
    input_data = jsontestdata('test_negative_mandatory_in_get_api.json')
    for input in input_data:
        get_holidays.request_for_holidays_list(input['key'], input['country'], input['year'])


def test_negative_additional_in_get_api():
    input_data = jsontestdata('test_negative_additional_in_get_api.json')
    for input in input_data:
        get_holidays.request_for_holidays_with_additional_fields(input['key'], input['country'], input['year'],input['month'],input['day'])


