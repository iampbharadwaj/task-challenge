import pytest
import logging
import json
import os
from pprint import pprint

def _load_json_data_from_file(file_name):
    """
    :param file_name: File name to be read
    :return:
    """
    try:
        with open(file_name) as data_file:
            if data_file:
                data = json.load(data_file)
                pprint(data)
                return data
            else:
                logging.error('No file found at location:{%s}', file_name)
    except (IOError, ValueError) as error:
        logging.exception(error)
    return None


def jsontestdata(file_name):
    json_data = _load_json_data_from_file(file_name)
    return json_data



#json_data = jsontestdata('test_mandatory_fields.json')
#print json_data['key']
