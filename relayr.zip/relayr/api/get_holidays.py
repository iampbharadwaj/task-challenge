import requests
from urlparse import urljoin
import json
import logging

logging.basicConfig(level=logging.INFO)

BASE_URL = "https://holidayapi.com/"
endpoint_url = "v1/holidays"

url = "https://holidayapi.com/v1/holidays"

#default_request_headers = {'Content-Type' : 'application/json', 'Accept' : 'application/json'}


def request_for_holidays_list(key,country,year):
    #request_headers = default_request_headers
    req_body = {"key": str(key), "country": str(country), "year": str(year)}
    response = requests.request("GET", url, params=req_body)
    if response.status_code == 200:
        logging.info('Successful')
        return True
    else:
       logging.error('Not working')


def request_for_holidays_with_additional_fields(key,country,year,month,day):
    #request_headers = default_request_headers
    req_body = {"key": str(key), "country": str(country), "year": str(year), "month": str(month), "day": str(day)}
    response = requests.request("GET", url, params=req_body)
    print(response.text)
    if response.status_code == 200:
        logging.info('Successful')
        return True
    else:
        logging.error('Not working')



